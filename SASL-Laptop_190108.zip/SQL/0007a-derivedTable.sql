﻿/*  
=== derivedTable  List of invoice numbers for orders $5 or more

Part A - Which invoices have a totoal of $5 or more.
   
==== TOPICS

* Join multiple tables 
* Aggregation functions to be used for count
* Table Alias
* Between function
* Date representation

  
==== TIPS

* Table alias shorten the typing needed to complete the query
1-3 character alias recommended.
* Column alias help to give meaningful, non conflicting names. 
Good practice is to have table alias used everywhere if used.
Use the same alias across all queries.
* Coulmns for join must match in data type and size
* Good practice is that System Generated Primary Key column name be named with `ID` at the end
* Good practice, alias column names use lowerUpper naming to identify them as alias (albumCount)
* Primary Key and Foreign Key matching columns should usew the same name

Invoice numbers for 2018 at or over $5
*/

select 
--  i.customerid  --<1>
  I.InvoiceID
--  ,i.InvoiceDate  --<1>
--  ,i.total  --<1>
from Invoice I 

where I.InvoiceDate between date '2018-01-01' and date '2018-12-31' --<2> <3>
and I.total >= 5.00