﻿/*

derivedTable  List of album/track info for other tracks that match 2018 order $5 or more track list

Part D - List of tracks and album information 
   
==== TOPICS

* Distinct to elminate duplicates
* Join multiple tables 
* Derived table or sub-query
* Aggregation functions to be used for count
* Table Alias
* Between function
* Date representation
* Group by columns
* Order By (Sort) columns
* Having (Aggregate filter)

  
==== TIPS

* Table alias shorten the typing needed to complete the query
1-3 character alias recommended.
* Column alias help to give meaningful, non conflicting names. 
Good practice is to have table alias used everywhere if used.
Use the same alias across all queries.
* Coulmns for join must match in data type and size
* Good practice is that System Generated Primary Key column name be named with `ID` at the end
* Good practice, alias column names use lowerUpper naming to identify them as alias 
* Primary Key and Foreign Key matching columns should usew the same name

*/

Select
	IL.TrackID	
	,T.Name as trackName   --<1>
	,A.AlbumID
	,A.AlbumTitle
	,count(T.TrackID) as trackCount  --<2>
from InvoiceLine IL

inner Join Track T
on T.TrackID = IL.TrackID

inner join Album A
on A.AlbumID = T.AlbumID

inner join
	( -- Any invoice with tracks from the 2018 invoice $5 or more track list  --<3>
	Select distinct   --<4>
	    IL.InvoiceID    
	from InvoiceLine IL
	
	inner join 
		( -- Track list for 2018 invoice $5 or more  --<5>
		Select 
		    IL.TrackID
		from invoiceline IL   
		
		inner join
			( -- 2018 Invoices $5 or more  --<6>
			select DISTINCT  --<4>
				I.InvoiceID	
			from Invoice I 
		    where I.InvoiceDate between date '2018-01-01' and date '2018-12-31' --<7><8>
		      and I.total >= 5.00
			) as RI  --<9>
		on RI.InvoiceID = IL.InvoiceID
		
		) TL --<10>
	on TL.TrackID = IL.TrackID	
	
	) as SI --<11>
on SI.InvoiceID = IL.InvoiceID 	

-- Syntax below is related to the top most query

group by --<12>
	IL.TrackID
	,T.Name
	,A.AlbumID
	,A.AlbumTitle
	
Order by 
	trackCount Desc  --<13>
	,trackname       --<14>
	
Having trackCount >= 2	--<15>