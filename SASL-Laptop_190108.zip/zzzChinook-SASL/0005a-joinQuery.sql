﻿/* 
=== joinQuery - Multiple Table join with result restriction
   
==== TOPICS

* This query joins multiple table together
   
==== TIPS

* Table alias shorten the typing needed to complete the query
1-2 character alias recommended.
* Column alias help to give meaningful, non conflicting names. 


 
*/

Select 
   AR.ArtistID
   ,AR.name as artistName  --<1>
From Artist AR  --<2>
inner join Album AL
on AR.ArtistID = AL.ArtistID
where artistName = 'Calexico' 