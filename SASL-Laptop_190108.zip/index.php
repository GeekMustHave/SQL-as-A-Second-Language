<?php
  header('Location: https://pwc-lms.com/SASL/readme.html', true, 301);
  exit();
?>