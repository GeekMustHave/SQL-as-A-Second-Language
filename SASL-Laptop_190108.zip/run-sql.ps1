$queryFile = "SQL/0001-tableCounts"

$profileName = "TeradataVM-PWCLab"


write-host "running: database5pro.exe 19 $($profileName) $($queryFile).sql -e:./Results/$($queryFile).xls"

database5pro.exe 19 $($profileName) "$($queryFile).sql" -e:"./Results/$($queryFile).xls"


