﻿/*

List of any track from any order with the tracklist from 2018 $5 or more


*/


Select
	IL.TrackID	
	,T.Name as trackName
	,A.AlbumID
	,A.AlbumTitle
	,count(T.TrackID) as trackCount
from InvoiceLine IL

inner Join Track T
on T.TrackID = IL.TrackID

inner join Album A
on A.AlbumID = T.AlbumID

inner join
	( -- Any invoice with tracks from the 2018 invoice $5 or more track list
	Select distinct
	    IL.InvoiceID    
	from InvoiceLine IL
	
	inner join 
		( -- Track list for 2018 invoice $5 or more
		Select 
		    IL.TrackID
		from invoiceline IL   
		
		inner join
			( -- 2018 Invoices $5 or more
			select
				I.InvoiceID	
			from Invoice I 
		    where I.InvoiceDate between date '2018-01-01' and date '2018-12-31'
		      and I.total >= 5.00
			) as RI
		on RI.InvoiceID = IL.InvoiceID
		
		) TL
	on TL.TrackID = IL.TrackID	
	
	) as SI
on SI.InvoiceID = IL.InvoiceID 	

-- Syntax below is related to the top most query

group by 
	IL.TrackID
	,T.Name
	,A.AlbumID
	,A.AlbumTitle
	
Order by 
	trackCount Desc
	,trackname
	
Having trackCount >= 2	