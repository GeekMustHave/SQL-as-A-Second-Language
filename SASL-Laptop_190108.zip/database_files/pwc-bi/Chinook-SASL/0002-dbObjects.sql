﻿/* 
=== dbObjects - Get a list of all the objects in a specific database
   
==== TOPICS

* This is a Teradata specific command
   
==== TIPS

* Change the database name from `chinook` to the database you are interested in 
*/

help database chinook