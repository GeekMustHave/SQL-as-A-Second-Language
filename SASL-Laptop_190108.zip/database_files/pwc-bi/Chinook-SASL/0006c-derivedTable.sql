﻿/* 
=== derivedTable - The derived table collects data on one topic (Albums)

Part C - Build the main query and include the two derived tables
   
==== TOPICS

* Table alias
* Column Alias
* Join objects (Table, View, Derived Table) together
* Result restriction (Where)
* Where like %Search% similar to `contains`
* Order by, sorting
* Derived Table (Sub-Query)

=== ASSUMPTIONS

* Every Artist has at least one album
   
==== TIPS

.Table Alias
* Table alias shorten the typing needed to complete the query, 
1-3 character alias recommended.
* Good practice is to have table alias used everywhere in the query.

.Column Alias
* Column alias help to give meaningful, non conflicting names. 
* Good practice, alias column names use lowerUpper naming 
to identify them as alias (albumCount)
* Good practic, Use the same alias across all queries.

.Naming practice
* Good practice, System Generated Primary Index column name be 
include with `ID` suffix.
* Good practice, Primary Key and Foreign Key join columns 
should use the same name.

.Join requirements
* Coulmns for join must match in data type and size.

.Where 
* The `and` combines two or more conditions for row restriction
* The `like` clause is similar to `conatins` when used with (%)
* The `like` wildcard (%) indicate 0 or more characters

.Order By
* Can use actual column name, column alias name, or ordinal position
* Ordinal position can become incorrect as you add more columns to the query

.Derived Tables (Sub-Queries)
* Start with a regular query until you get the results you need
* Enclose the regular query in `(...)` and assign a table alias
* Join the derived table to another
 
*/

Select 
	AR.ArtistID
	,AR.Name as artistName
	,AC.albumCount   
	,TC.totalMinutes
	,cast(TC.avgMinutes as decimal(5,2))  as averageMinutes  
from Artist AR

inner join
	(                  
	select
	    AR.ArtistID
		,count(AL.AlbumID) as albumCount  
	from Album AL -
	
	INNER JOIN Artist AR  
	on AR.ArtistID = AL.ArtistID 
	
	Group by AR.ArtistID  
	) as AC               
on AC.ArtistID = AR.ArtistID

inner Join
	(                     
	Select 
	    AL.ArtistID 
	    ,count(T.TrackID) as trackCount
	    ,sum(T.Milliseconds) / 60000.00 as totalMinutes  
	    ,avg(T.Milliseconds) / 60000.00 as avgMinutes    
	from Album AL    
	
	inner Join Track T
	on T.AlbumID = AL.AlbumID
	
	group by AL.ArtistID
	) as TC                
on TC.ArtistID = AR.ArtistID

Order by artistName	