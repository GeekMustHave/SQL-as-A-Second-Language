﻿/*
list invoices with tracks matching 2018 $5
*/

Select distinct
    IL.InvoiceID    
from InvoiceLine IL

inner join 
	( -- Track list for 2018 invoice $5 or more
	Select 
	    IL.TrackID
	from invoiceline IL   
	
	inner join
		( -- 2018 Invoices $5 or more
		select
			I.InvoiceID	
		from Invoice I 
	    where I.InvoiceDate between date '2018-01-01' and date '2018-12-31'
	      and I.total >= 5.00
		) as RI
	on RI.InvoiceID = IL.InvoiceID
	
	) TL
on TL.TrackID = IL.TrackID	
	



    