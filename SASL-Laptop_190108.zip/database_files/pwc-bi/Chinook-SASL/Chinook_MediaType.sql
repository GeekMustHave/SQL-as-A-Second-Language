﻿INSERT INTO "Chinook"."MediaType" ("MediaTypeId","Name") VALUES (5,'AAC audio file');
INSERT INTO "Chinook"."MediaType" ("MediaTypeId","Name") VALUES (3,'Protected MPEG-4 video file');
INSERT INTO "Chinook"."MediaType" ("MediaTypeId","Name") VALUES (1,'MPEG audio file');
INSERT INTO "Chinook"."MediaType" ("MediaTypeId","Name") VALUES (4,'Purchased AAC audio file');
INSERT INTO "Chinook"."MediaType" ("MediaTypeId","Name") VALUES (2,'Protected AAC audio file');
