﻿/*
Invoice numbers for 2018 at or over $5
*/

select 
--  i.customerid
  I.InvoiceID
--  ,i.InvoiceDate
--  ,i.total
from Invoice I 

where I.InvoiceDate between date '2018-01-01' and date '2018-12-31'
and I.total >= 5.00